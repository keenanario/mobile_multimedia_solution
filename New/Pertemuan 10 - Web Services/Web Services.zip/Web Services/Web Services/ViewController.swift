//
//  ViewController.swift
//  Web Services
//
//  Created by prk on 5/24/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var animeTableView: UITableView!
    
    var animeItems = [AnimeData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = "https://api.jikan.moe/v4/seasons/now"
        
        //register tableview dan view cell
        animeTableView.dataSource = self
        animeTableView.register(UINib(nibName: "AnimeTableViewCell", bundle: nil), forCellReuseIdentifier: "AnimeCell")
        
        //passing url ke fungsi load data
        getDataFromURL(from: url)
    }
    
    //hitung jumlah data
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animeItems.count
    }
    
    //mapping data ke cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "AnimeCell", for: indexPath) as? AnimeTableViewCell{
            let anime = animeItems[indexPath.row] //populate data per row
            cell.titleLabel.text = anime.title
            
            return cell
        }else{
            return UITableViewCell()
        }
    }
    
    //untuk get data dari API
    private func getDataFromURL(from url: String){
        //konek ke API menggunakan URLSession
        URLSession.shared.dataTask(with: URL(string:url)!, completionHandler: {data, response, error in
            guard let data = data, error == nil else{
                print("something wrong") //jika terjadi error atau data kosong
                return
            }
            
            //kalau berhasil dan ada data
            var result: Response?
            do{
                result = try JSONDecoder().decode(Response.self, from: data)
            }catch{
                print("failed to convert data \(error)")
            }
            
            guard let json = result else{
                return
            }
            
            json.data.forEach{data in print(data.title)}
            
            //pasang data di tableview
            self.animeItems = json.data
            
        }).resume()
    }
}

struct Response: Codable{
    let pagination: AnimePagination
    let data: [AnimeData]
}

struct AnimePagination: Codable{
    let last_visible_page: Int
    let has_next_page: Bool
    let current_page: Int
}

struct AnimeData: Codable{
    let mal_id: Int
    let title: String
}

