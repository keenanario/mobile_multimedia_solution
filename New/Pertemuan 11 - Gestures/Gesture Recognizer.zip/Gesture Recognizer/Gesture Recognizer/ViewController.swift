//
//  ViewController.swift
//  Gesture Recognizer
//
//  Created by prk on 5/31/23.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    @IBOutlet weak var touchLabel: UILabel! //touch
    @IBOutlet weak var fingerLabel: UILabel! //finger count
    @IBOutlet weak var tapLabel: UILabel! //tap
    @IBOutlet weak var swipeLabel: UILabel! //swipe
    @IBOutlet weak var pinchRotateLabel: UILabel! //pinch and rotate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //handle tap
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(handleSingleTap))
        singleTap.numberOfTouchesRequired = 1
        singleTap.numberOfTapsRequired = 1
        view.addGestureRecognizer(singleTap)
        
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap))
        doubleTap.numberOfTouchesRequired = 1
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)
        
        //handle swipe
        let verticalSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleVerticalSwipe(_:)))
        verticalSwipe.direction = [.up, .down]
        view.addGestureRecognizer(verticalSwipe)
        
        let horizontalSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleHorizontalSwipe(_:)))
        horizontalSwipe.direction = [.left, .right]
        view.addGestureRecognizer(horizontalSwipe)
        
        //pinch
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
        pinchGesture.delegate = self
        view.addGestureRecognizer(pinchGesture)
        
        //rotate
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation(_:)))
        rotateGesture.delegate = self
        view.addGestureRecognizer(rotateGesture)
    }
    
    //touches
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchLabel.text = "Touch Began"
        updateLabelFromTouch(touches.first, allTouches: event?.allTouches)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchLabel.text = "Drag Began"
        updateLabelFromTouch(touches.first, allTouches: event?.allTouches)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchLabel.text = "Touch Ended"
        updateLabelFromTouch(touches.first, allTouches: event?.allTouches)
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchLabel.text = "Touch Canceled"
    }
    
    private func updateLabelFromTouch(_ touch: UITouch?, allTouches: Set<UITouch>? ){
        let numberOfTouches = allTouches?.count ?? 0
        let touchMessage = "\(numberOfTouches) fingers detected"
        fingerLabel.text = touchMessage
    }
    
    //tap
    @objc func handleSingleTap(){
        let tapMessage = "Single tap detected"
        tapLabel.text = tapMessage
    }
    
    @objc func handleDoubleTap(){
        let tapMessage = "Double tap detected"
        tapLabel.text = tapMessage
    }
    
    //swipe
    @objc func handleVerticalSwipe(_ recognizer: UIGestureRecognizer){
        swipeLabel.text = "Vertical Swipe Detected"
    }
    
    @objc func handleHorizontalSwipe(_ recognizer: UIGestureRecognizer){
        swipeLabel.text = "Horizontal Swipe Detected"
    }
    
    //pinch
    @objc func handlePinch(_ gesture: UIPinchGestureRecognizer){
        pinchRotateLabel.text = "Pinch Detected"
    }
    
    //rotation
    @objc func handleRotation(_ gesture: UIRotationGestureRecognizer){
        pinchRotateLabel.text = "Rotation Detected"
    }
}

